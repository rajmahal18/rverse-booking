import { useEffect, useMemo, useState } from 'react'
import { Link } from 'react-router-dom'
import DemoBar from '../components/DemoBar'
import PickleRVerseBrand from '../components/PickleRVerseBrand'
import { CalendarIcon, GridIcon, ListIcon, PlusIcon, UsersIcon, WalletIcon, CheckIcon } from '../components/Icons'
import { bookingTimes, courts, isDurationAvailable, isOccupied, loadDemoState, makeDates, makeReference, money, saveDemoState, shortDate, timeSlots, venue, type DemoBooking, type DemoState } from '../lib/demoStore'

type Tab = 'overview'|'schedule'|'bookings'|'payments'

export default function AdminDemo() {
  const dates = makeDates(7)
  const [state, setState] = useState<DemoState>(loadDemoState())
  const [tab, setTab] = useState<Tab>('overview')
  const [date, setDate] = useState(dates[0].iso)
  const [selected, setSelected] = useState<DemoBooking | null>(null)
  const [manualOpen, setManualOpen] = useState(false)
  const [manualName, setManualName] = useState('Walk-in player')
  const [manualCourt, setManualCourt] = useState(courts[0].id)
  const [manualTime, setManualTime] = useState('3:00 PM')
  const [moveTime, setMoveTime] = useState('')

  useEffect(() => { if (selected) setMoveTime(selected.time) }, [selected])

  function update(next: DemoState) { setState(next); saveDemoState(next) }
  const dayBookings = useMemo(() => state.bookings.filter(b => b.date === date), [state,date])
  const pending = state.bookings.filter(b => b.paymentStatus === 'Pending review')
  const paidRevenue = state.bookings.filter(b=>b.paymentStatus==='Paid').reduce((sum,b)=>sum+b.amount,0)

  function toggleBlock(courtId:string,time:string) {
    const key = `${date}|${courtId}|${time}`
    const isBooked = dayBookings.some(b => b.courtId===courtId && bookingTimes(b).includes(time))
    if (isBooked) return
    const nextBlocked = state.blocked.includes(key) ? state.blocked.filter(x=>x!==key) : [...state.blocked,key]
    update({ ...state, blocked:nextBlocked })
  }

  function verify(id:string) {
    const next = { ...state, bookings:state.bookings.map(b => b.id===id ? {...b,paymentStatus:'Paid' as const} : b) }
    update(next)
    if (selected?.id===id) setSelected(next.bookings.find(b=>b.id===id) || null)
  }

  function createManual() {
    if (isOccupied(state,date,manualCourt,manualTime)) return
    const court = courts.find(c=>c.id===manualCourt)!
    const id = makeReference(state)
    const booking: DemoBooking = { id,customer:manualName || 'Walk-in player',phone:'—',courtId:court.id,courtName:court.name,date,time:manualTime,duration:1,amount:court.rate,paymentMethod:'Cash',paymentStatus:'Unpaid',source:'Staff',createdAt:new Date().toISOString() }
    update({ ...state, bookings:[booking,...state.bookings] })
    setManualOpen(false); setTab('bookings'); setSelected(booking)
  }

  function availableTimesFor(booking: DemoBooking) {
    const withoutBooking = { ...state, bookings: state.bookings.filter(b => b.id !== booking.id) }
    return timeSlots.filter(t => isDurationAvailable(withoutBooking, booking.date, booking.courtId, t, booking.duration))
  }

  function rescheduleSelected() {
    if (!selected || !moveTime) return
    const options = availableTimesFor(selected)
    if (!options.includes(moveTime)) return
    const nextBooking = { ...selected, time: moveTime }
    const next = { ...state, bookings: state.bookings.map(b => b.id === selected.id ? nextBooking : b) }
    update(next)
    setSelected(nextBooking)
  }

  function cancelSelected() {
    if (!selected) return
    update({ ...state, bookings: state.bookings.filter(b => b.id !== selected.id) })
    setSelected(null)
  }

  function slot(courtId:string,time:string) {
    const booking = dayBookings.find(b=>b.courtId===courtId && bookingTimes(b).includes(time))
    const blocked = state.blocked.includes(`${date}|${courtId}|${time}`)
    if (booking) return <button className={`schedule-cell booked ${booking.paymentStatus==='Pending review'?'pending':''}`} onClick={()=>setSelected(booking)}><strong>{booking.customer}</strong><small>{booking.paymentStatus}</small></button>
    if (blocked) return <button className="schedule-cell blocked" onClick={()=>toggleBlock(courtId,time)}><strong>Blocked</strong><small>Click to open</small></button>
    return <button className="schedule-cell available" onClick={()=>toggleBlock(courtId,time)}><span>Available</span><small>Click to block</small></button>
  }

  return (
    <div className="admin-shell">
      <DemoBar />
      <div className="admin-app">
        <aside className="admin-sidebar">
          <Link to="/demo" className="admin-brand admin-brand-custom"><PickleRVerseBrand markOnly/><span><strong>PickleRVerse</strong><small>Court Staff</small></span></Link>
          <nav>
            <button className={tab==='overview'?'active':''} onClick={()=>setTab('overview')}><GridIcon/>Overview</button>
            <button className={tab==='schedule'?'active':''} onClick={()=>setTab('schedule')}><CalendarIcon/>Schedule</button>
            <button className={tab==='bookings'?'active':''} onClick={()=>setTab('bookings')}><ListIcon/>Bookings</button>
            <button className={tab==='payments'?'active':''} onClick={()=>setTab('payments')}><WalletIcon/>Payments {pending.length>0&&<b>{pending.length}</b>}</button>
          </nav>
          <div className="admin-sidebar-note"><span>PickleRVerse workspace</span><p>{venue.locationLabel}<br/>{venue.hours}</p></div>
        </aside>

        <main className="admin-content">
          <header className="admin-top"><div><span>PickleRVerse / Court Staff · {venue.locationLabel}</span><h1>{tab[0].toUpperCase()+tab.slice(1)}</h1></div><button className="admin-primary" onClick={()=>setManualOpen(true)}><PlusIcon/>New booking</button></header>

          {tab==='overview' && <div className="admin-view">
            <section className="admin-venue-banner"><img src="/brand/picklerverse-venue.webp" alt="PickleRVerse venue"/><div><PickleRVerseBrand/><span>{venue.address}</span><small>{venue.phone} · {venue.hours}</small></div></section>
            <section className="admin-metrics"><article><span>Today’s bookings</span><strong>{state.bookings.filter(b=>b.date===dates[0].iso).length}</strong><small>Orbit · Nova · Comet</small></article><article><span>Paid revenue</span><strong>{money(paidRevenue)}</strong><small>Demo records</small></article><article><span>Needs review</span><strong>{pending.length}</strong><small>Payment proofs</small></article></section>
            <section className="admin-panel"><div className="panel-head"><div><span>Today</span><h2>Courts at a glance</h2></div><button onClick={()=>setTab('schedule')}>Open schedule →</button></div><div className="overview-schedule">{courts.map(c=><div key={c.id}><span>{c.name}</span>{timeSlots.slice(6,12).map(t=>{const b=state.bookings.find(x=>x.date===dates[0].iso&&x.courtId===c.id&&bookingTimes(x).includes(t));const blocked=state.blocked.includes(`${dates[0].iso}|${c.id}|${t}`);return <i key={t} className={b?'busy':blocked?'blocked':''} title={`${t} · ${b?b.customer:blocked?'Blocked':'Available'}`}></i>})}</div>)}</div></section>
            <section className="admin-split"><div className="admin-panel"><div className="panel-head"><div><span>Latest</span><h2>Recent bookings</h2></div><button onClick={()=>setTab('bookings')}>View all →</button></div><div className="mini-bookings">{state.bookings.slice(0,4).map(b=><button key={b.id} onClick={()=>setSelected(b)}><span><strong>{b.customer}</strong><small>{b.id} · {b.courtName}</small></span><span><strong>{shortDate(b.date)}</strong><small>{b.time}</small></span><i className={b.paymentStatus==='Paid'?'paid':b.paymentStatus==='Pending review'?'pending':''}>{b.paymentStatus}</i></button>)}</div></div>
            <div className="admin-panel"><div className="panel-head"><div><span>Payments</span><h2>Waiting for review</h2></div></div>{pending.length?<div className="review-queue">{pending.slice(0,3).map(b=><div key={b.id}><span><strong>{b.customer}</strong><small>{b.proofName||'Payment proof'}</small></span><button onClick={()=>verify(b.id)}><CheckIcon/>Verify</button></div>)}</div>:<div className="empty-state">No proofs waiting for review.</div>}</div></section>
          </div>}

          {tab==='schedule' && <div className="admin-view"><div className="admin-toolbar"><div className="admin-date-tabs">{dates.slice(0,5).map(d=><button className={date===d.iso?'active':''} key={d.iso} onClick={()=>setDate(d.iso)}><small>{d.dow}</small><strong>{d.day}</strong></button>)}</div><p>Click an empty slot to block or unblock it.</p></div><div className="schedule-grid"><div className="schedule-grid-head"><span>Time</span>{courts.map(c=><strong key={c.id}>{c.name}</strong>)}</div>{timeSlots.map(time=><div className="schedule-grid-row" key={time}><span>{time}</span>{courts.map(c=><div key={c.id}>{slot(c.id,time)}</div>)}</div>)}</div></div>}

          {tab==='bookings' && <div className="admin-view"><div className="list-head"><div><span>All demo records</span><h2>{state.bookings.length} bookings</h2></div><div className="legend"><span><i className="dot paid"></i>Paid</span><span><i className="dot pending"></i>Pending review</span><span><i className="dot"></i>Unpaid</span></div></div><div className="booking-table"><div className="booking-table-head"><span>Booking</span><span>Schedule</span><span>Payment</span><span>Source</span></div>{state.bookings.map(b=><button key={b.id} onClick={()=>setSelected(b)}><span><strong>{b.customer}</strong><small>{b.id}</small></span><span><strong>{b.courtName}</strong><small>{shortDate(b.date)} · {b.time} · {b.duration}h</small></span><span><strong>{money(b.amount)}</strong><small className={b.paymentStatus==='Paid'?'paid-text':b.paymentStatus==='Pending review'?'pending-text':''}>{b.paymentStatus}</small></span><span><strong>{b.source}</strong><small>{b.paymentMethod}</small></span></button>)}</div></div>}

          {tab==='payments' && <div className="admin-view"><div className="list-head"><div><span>Manual verification</span><h2>Payment proofs</h2></div><p>Verification updates the booking record immediately.</p></div>{pending.length?<div className="payment-review-grid">{pending.map(b=><article key={b.id}><div className="proof-visual"><div className="admin-proof-brand"><PickleRVerseBrand markOnly/><span>{venue.paymentName}</span></div><span>PAYMENT PROOF</span><strong>{money(b.amount)}</strong><small>{b.proofName||'sample-proof.jpg'}</small><i>Demo upload</i></div><div className="proof-details"><span>{b.id}</span><h3>{b.customer}</h3><p>{b.courtName} · {shortDate(b.date)} · {b.time}</p><dl><div><dt>Method</dt><dd>{b.paymentMethod}</dd></div><div><dt>Status</dt><dd className="pending-text">{b.paymentStatus}</dd></div></dl><button onClick={()=>verify(b.id)}><CheckIcon/>Verify payment</button></div></article>)}</div>:<div className="large-empty"><CheckIcon/><h2>Everything is reviewed.</h2><p>Create a public booking with “Upload payment proof” to populate this queue again.</p><Link to="/demo/book">Create demo booking →</Link></div>}</div>}
        </main>
      </div>

      {selected && <div className="admin-drawer-layer" onMouseDown={e=>e.currentTarget===e.target&&setSelected(null)}><aside className="booking-drawer"><button className="drawer-close" onClick={()=>setSelected(null)}>×</button><span>{selected.id}</span><h2>{selected.customer}</h2><p>{selected.courtName} · {shortDate(selected.date)} · {selected.time}</p><div className="drawer-facts"><div><span>Duration</span><strong>{selected.duration} hour{selected.duration>1?'s':''}</strong></div><div><span>Amount</span><strong>{money(selected.amount)}</strong></div><div><span>Payment</span><strong>{selected.paymentMethod}</strong></div><div><span>Status</span><strong className={selected.paymentStatus==='Paid'?'paid-text':selected.paymentStatus==='Pending review'?'pending-text':''}>{selected.paymentStatus}</strong></div><div><span>Source</span><strong>{selected.source}</strong></div>{selected.proofName&&<div><span>Proof</span><strong>{selected.proofName}</strong></div>}</div><div className="drawer-reschedule"><label>Move booking to<select value={moveTime} onChange={e=>setMoveTime(e.target.value)}>{availableTimesFor(selected).map(t=><option key={t}>{t}</option>)}</select></label><button onClick={rescheduleSelected} disabled={moveTime===selected.time}>Update time</button></div>{selected.paymentStatus==='Pending review'&&<button className="admin-primary drawer-action" onClick={()=>verify(selected.id)}><CheckIcon/>Verify payment</button>}<button className="drawer-cancel" onClick={cancelSelected}>Cancel booking</button></aside></div>}

      {manualOpen && <div className="admin-drawer-layer" onMouseDown={e=>e.currentTarget===e.target&&setManualOpen(false)}><aside className="booking-drawer manual-drawer"><button className="drawer-close" onClick={()=>setManualOpen(false)}>×</button><span>Manual booking</span><h2>Add a walk-in.</h2><label>Player name<input value={manualName} onChange={e=>setManualName(e.target.value)}/></label><label>Court<select value={manualCourt} onChange={e=>setManualCourt(e.target.value)}>{courts.map(c=><option value={c.id} key={c.id}>{c.name}</option>)}</select></label><label>Date<select value={date} onChange={e=>setDate(e.target.value)}>{dates.map(d=><option value={d.iso} key={d.iso}>{d.label}</option>)}</select></label><label>Time<select value={manualTime} onChange={e=>setManualTime(e.target.value)}>{timeSlots.map(t=><option key={t} disabled={isOccupied(state,date,manualCourt,t)}>{t}{isOccupied(state,date,manualCourt,t)?' — unavailable':''}</option>)}</select></label><button className="admin-primary drawer-action" onClick={createManual}><PlusIcon/>Create unpaid booking</button></aside></div>}
    </div>
  )
}
