# RVerse Booking Systems — Sales + PickleRVerse Demo

React + Vite + TypeScript sales site with a fully branded fictional **PickleRVerse** venue simulation.

The public demo is intentionally designed like a separate client website—not a reskin of the RVerse sales page. It demonstrates how a real court can have its own logo, palette, venue imagery, court names, rates, rules, payment instructions, and staff workspace.

## Routes

- `/` — RVerse sales site
- `/demo` — PickleRVerse public venue site
- `/demo/book` — player booking + payment simulation
- `/demo/admin` — Court Staff simulation using the same browser state

Entering the sample court from the primary sales CTAs first asks the visitor to choose:

- **Book as a Player**
- **Manage as Court Staff**

## PickleRVerse sample configuration

- Courts: **Orbit**, **Nova**, **Comet**
- Individual court rates and descriptions
- Open hours and venue contact details
- Amenities and house rules
- GCash / Maya / Card demo checkout
- Manual payment-proof path with branded recipient details
- Official PickleRVerse logo and generated venue imagery
- Shared public/staff schedule and booking state

Optimized web assets live in `public/brand/`:

- `picklerverse-logo.webp`
- `picklerverse-mark.webp`
- `picklerverse-venue.webp`
- `picklerverse-aerial.webp`

The original generated PNGs remain in `public/` as source assets.

## Demo behavior

- Dynamic dates (`Today`, `Tomorrow`, then chronological dates)
- Single chronological time schedule from 7 AM to 9 PM
- Duration-aware availability
- Multi-hour bookings visibly occupy consecutive schedule rows
- Booked / blocked / insufficient-duration start times clearly distinguished
- Customer details step
- Simulated online payment
- Manual payment-proof upload
- Booking reference generation
- Paid / Unpaid / Pending review states
- Shared `localStorage` state between Player and Court Staff
- Court Staff overview, schedule, bookings, and payment review
- Block / unblock schedule time
- Manual walk-in booking
- Payment verification
- Rescheduling
- Cancellation
- Reset demo state

No real payment is processed and selected upload files are not sent anywhere.

## Tech stack

- React
- TypeScript
- Vite
- React Router
- Motion (`motion/react`)
- Custom CSS
- Browser `localStorage` + `sessionStorage` for demo state/perspective

There is no backend in this sales MVP.

## Run locally

```bash
npm install
npm run dev
```

## Checks and production build

```bash
npm run check
npm run build
npm run preview
```

## Deploy to Vercel

- Framework preset: **Vite**
- Build command: `npm run build`
- Output directory: `dist`

`vercel.json` includes the SPA fallback.

## Deploy to Cloudflare Pages

- Framework preset: **Vite**
- Build command: `npm run build`
- Output directory: `dist`

`public/_redirects` provides the SPA fallback.
