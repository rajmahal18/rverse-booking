import { motion, AnimatePresence } from 'motion/react'
import { useNavigate } from 'react-router-dom'
import { Arrow, CalendarIcon, GridIcon } from './Icons'
import { setDemoRole, type DemoRole } from '../lib/demoRole'
import PickleRVerseBrand from './PickleRVerseBrand'

export default function DemoRoleChooser({ open, onChoose }: { open: boolean; onChoose?: (role: DemoRole) => void }) {
  const navigate = useNavigate()

  function choose(role: DemoRole) {
    setDemoRole(role)
    onChoose?.(role)
    navigate(role === 'staff' ? '/demo/admin' : '/demo')
  }

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          className="role-gateway"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.18 }}
        >
          <motion.section
            className="role-card"
            initial={{ opacity: 0, y: 18, scale: 0.985 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 12, scale: 0.99 }}
            transition={{ type: 'spring', stiffness: 340, damping: 30 }}
          >
            <div className="role-card-head">
              <PickleRVerseBrand className="role-brand"/>
              <span>Sample court · booking-system demo</span>
              <strong>Explore PickleRVerse from either side.</strong>
              <p>The public court and Court Staff workspace use the same dummy schedule, bookings, and payment status.</p>
            </div>
            <div className="role-options">
              <button onClick={() => choose('player')}>
                <span className="role-icon"><CalendarIcon /></span>
                <span><b>Book as a player</b><small>See the public booking experience from court selection to payment.</small></span>
                <Arrow />
              </button>
              <button onClick={() => choose('staff')}>
                <span className="role-icon"><GridIcon /></span>
                <span><b>Manage as court staff</b><small>Open the schedule, bookings, payment proofs, and staff controls.</small></span>
                <Arrow />
              </button>
            </div>
            <small className="role-disclaimer">Simulation only. No real payment is processed.</small>
          </motion.section>
        </motion.div>
      )}
    </AnimatePresence>
  )
}
