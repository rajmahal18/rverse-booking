# RVerse Booking — PickleRVerse Demo

Vite + React + TypeScript sales site and interactive fictional court demo.

## V1.2 Living Court direction

The fictional PickleRVerse venue now drives the visual system: court blue, apron lime, fence navy, sky, concrete, and foliage tones are reused across the player, booking, booking-management, and Court Staff views. The public venue is intentionally kinetic while the booking workflow stays first-glance simple on phones.

Key UX and visual choices:
- The public venue uses a continuous rally motif: moving pickleball, paddle swings, court-line overlays, kinetic text, and scroll-reactive motion.
- Venue photography is the palette source, so the interface blends with the fictional physical court instead of feeling like a separate SaaS template.
- Player browsing keeps the labeled mobile nav: Venue / Book / My booking.
- Booking keeps every court in one compact schedule with A / B / R / M / ✓ status codes and uses the same venue-derived palette.
- Checkout still uses a simple Step X of 4 progress bar and a sticky booking cart.
- Court Staff keeps the same schedule language and inherits the venue palette without adding distracting motion to operational screens.
- Motion respects reduced-motion preferences, and core booking actions remain obvious without animation.
- Sales-page guides, pricing details, FAQs, and product explanations remain available.

## Run locally

```bash
npm install
npm run check
npm run dev
```

Production build:

```bash
npm run build
npm run preview
```

## Main routes

- `/` — sales site
- `/demo` — PickleRVerse player-facing venue
- `/demo/book` — booking simulation
- `/demo/manage` — booking lookup and management
- `/demo/admin` — Court Staff workspace

## Deployment

### Vercel
- Framework preset: Vite
- Build command: `npm run build`
- Output directory: `dist`

`vercel.json` contains the SPA rewrite.

### Cloudflare Pages
- Framework preset: Vite
- Build command: `npm run build`
- Build output directory: `dist`

`public/_redirects` contains the SPA fallback.

## Demo state

The demo uses `localStorage`. Player bookings and Court Staff changes share the same browser state. Use **Reset** in the demo bar to return to seeded PickleRVerse data.
