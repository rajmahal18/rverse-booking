import type { SVGProps } from 'react'

const base = { width: 20, height: 20, viewBox: '0 0 24 24', fill: 'none', stroke: 'currentColor', strokeWidth: 1.7, strokeLinecap: 'round' as const, strokeLinejoin: 'round' as const }
export function Arrow(props: SVGProps<SVGSVGElement>) { return <svg {...base} {...props}><path d="M5 12h14M13 6l6 6-6 6"/></svg> }
export function CalendarIcon(props: SVGProps<SVGSVGElement>) { return <svg {...base} {...props}><rect x="3" y="5" width="18" height="16" rx="2"/><path d="M8 3v4M16 3v4M3 10h18"/></svg> }
export function CardIcon(props: SVGProps<SVGSVGElement>) { return <svg {...base} {...props}><rect x="3" y="5" width="18" height="14" rx="2"/><path d="M3 10h18M7 15h4"/></svg> }
export function ClockIcon(props: SVGProps<SVGSVGElement>) { return <svg {...base} {...props}><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg> }
export function CheckIcon(props: SVGProps<SVGSVGElement>) { return <svg {...base} {...props}><path d="m5 12 4 4L19 6"/></svg> }
export function Chevron(props: SVGProps<SVGSVGElement>) { return <svg {...base} {...props}><path d="m9 18 6-6-6-6"/></svg> }
export function UploadIcon(props: SVGProps<SVGSVGElement>) { return <svg {...base} {...props}><path d="M12 16V4M7 9l5-5 5 5M5 20h14"/></svg> }
export function UsersIcon(props: SVGProps<SVGSVGElement>) { return <svg {...base} {...props}><path d="M16 21v-2a4 4 0 0 0-4-4H7a4 4 0 0 0-4 4v2M9.5 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8M17 11a3 3 0 0 0 0-6M21 21v-2a4 4 0 0 0-3-3.87"/></svg> }
export function GridIcon(props: SVGProps<SVGSVGElement>) { return <svg {...base} {...props}><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/></svg> }
export function ListIcon(props: SVGProps<SVGSVGElement>) { return <svg {...base} {...props}><path d="M8 6h13M8 12h13M8 18h13M3 6h.01M3 12h.01M3 18h.01"/></svg> }
export function WalletIcon(props: SVGProps<SVGSVGElement>) { return <svg {...base} {...props}><path d="M4 6h14a2 2 0 0 1 2 2v10H5a2 2 0 0 1-2-2V6a3 3 0 0 1 3-3h11"/><path d="M16 11h5v4h-5a2 2 0 0 1 0-4Z"/></svg> }
export function PlusIcon(props: SVGProps<SVGSVGElement>) { return <svg {...base} {...props}><path d="M12 5v14M5 12h14"/></svg> }
export function ResetIcon(props: SVGProps<SVGSVGElement>) { return <svg {...base} {...props}><path d="M3 12a9 9 0 1 0 3-6.7L3 8"/><path d="M3 3v5h5"/></svg> }
export function ExternalIcon(props: SVGProps<SVGSVGElement>) { return <svg {...base} {...props}><path d="M14 3h7v7M10 14 21 3M21 14v5a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5"/></svg> }
