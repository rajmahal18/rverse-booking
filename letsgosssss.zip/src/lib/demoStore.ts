export type PaymentStatus = 'Paid' | 'Pending review' | 'Unpaid'
export type BookingSource = 'Public' | 'Staff'

export type DemoBooking = {
  id: string
  customer: string
  phone: string
  courtId: string
  courtName: string
  date: string
  time: string
  duration: number
  amount: number
  paymentMethod: string
  paymentStatus: PaymentStatus
  source: BookingSource
  proofName?: string
  createdAt: string
}

export type DemoState = {
  bookings: DemoBooking[]
  blocked: string[]
}

export const venue = {
  name: 'PickleRVerse',
  type: 'Open-air pickleball club',
  address: '88 Orbit Avenue, Cotabato City',
  locationLabel: 'Cotabato City',
  hours: '7:00 AM–10:00 PM daily',
  phone: '0917 808 7787',
  social: '@PickleRVerse',
  paymentName: 'PickleRVerse Sports',
  paymentNumber: '0917 808 7787',
  amenities: ['Free parking', 'Paddle rental', 'Waiting lounge', 'Comfort room', 'Water station'],
  rules: [
    'Arrive 10 minutes before your schedule.',
    'Reschedule at least 6 hours before play.',
    'Use proper court shoes; non-marking soles preferred.',
    'Booked time includes warm-up and court turnover.',
  ],
}

export const courts = [
  {
    id: 'orbit',
    name: 'Orbit Court',
    shortName: 'Orbit',
    number: '01',
    surface: 'Competition acrylic',
    note: 'Signature court · closest to the lounge',
    rate: 350,
  },
  {
    id: 'nova',
    name: 'Nova Court',
    shortName: 'Nova',
    number: '02',
    surface: 'Social-play acrylic',
    note: 'Center court · balanced lighting',
    rate: 320,
  },
  {
    id: 'comet',
    name: 'Comet Court',
    shortName: 'Comet',
    number: '03',
    surface: 'Training acrylic',
    note: 'Coaching-friendly · quieter side',
    rate: 300,
  },
]

export const timeSlots = ['7:00 AM','8:00 AM','9:00 AM','10:00 AM','11:00 AM','12:00 PM','1:00 PM','2:00 PM','3:00 PM','4:00 PM','5:00 PM','6:00 PM','7:00 PM','8:00 PM','9:00 PM']

const key = 'picklerverse-demo-state-v2'

function dateISO(offset = 0) {
  const d = new Date()
  d.setHours(12,0,0,0)
  d.setDate(d.getDate() + offset)
  return d.toISOString().slice(0,10)
}

export function makeDates(count = 7) {
  return Array.from({ length: count }, (_, i) => {
    const d = new Date()
    d.setHours(12,0,0,0)
    d.setDate(d.getDate() + i)
    return {
      iso: d.toISOString().slice(0,10),
      dow: d.toLocaleDateString('en-PH', { weekday: 'short' }),
      day: d.toLocaleDateString('en-PH', { day: '2-digit' }),
      month: d.toLocaleDateString('en-PH', { month: 'short' }),
      label: i === 0 ? 'Today' : i === 1 ? 'Tomorrow' : d.toLocaleDateString('en-PH', { weekday: 'short', month: 'short', day: 'numeric' }),
    }
  })
}

function seedState(): DemoState {
  return {
    bookings: [
      { id: 'PRV-2048', customer: 'Mia Santos', phone: '0917 555 0148', courtId: 'orbit', courtName: 'Orbit Court', date: dateISO(0), time: '6:00 PM', duration: 2, amount: 720, paymentMethod: 'GCash', paymentStatus: 'Paid', source: 'Public', createdAt: new Date().toISOString() },
      { id: 'PRV-2049', customer: 'Anton Cruz', phone: '0918 222 1044', courtId: 'nova', courtName: 'Nova Court', date: dateISO(0), time: '4:00 PM', duration: 1, amount: 330, paymentMethod: 'Manual proof', paymentStatus: 'Pending review', source: 'Public', proofName: 'gcash-proof-2049.jpg', createdAt: new Date().toISOString() },
      { id: 'PRV-2050', customer: 'Jules Reyes', phone: '0919 883 2201', courtId: 'comet', courtName: 'Comet Court', date: dateISO(1), time: '8:00 AM', duration: 1, amount: 310, paymentMethod: 'Cash', paymentStatus: 'Unpaid', source: 'Staff', createdAt: new Date().toISOString() },
    ],
    blocked: [`${dateISO(0)}|orbit|9:00 PM`, `${dateISO(1)}|nova|1:00 PM`],
  }
}

export function loadDemoState(): DemoState {
  try {
    const stored = localStorage.getItem(key)
    if (stored) return JSON.parse(stored) as DemoState
  } catch {}
  const seeded = seedState()
  saveDemoState(seeded)
  return seeded
}

export function saveDemoState(state: DemoState) {
  localStorage.setItem(key, JSON.stringify(state))
  window.dispatchEvent(new CustomEvent('picklerverse-demo-change'))
}

export function resetDemoState() {
  const state = seedState()
  saveDemoState(state)
  return state
}

export function isOccupied(state: DemoState, date: string, courtId: string, time: string) {
  const blocked = state.blocked.includes(`${date}|${courtId}|${time}`)
  const booked = state.bookings.some((b) => b.date === date && b.courtId === courtId && bookingTimes(b).includes(time))
  return blocked || booked
}

export function isDurationAvailable(state: DemoState, date: string, courtId: string, time: string, duration: number) {
  const index = timeSlots.indexOf(time)
  if (index < 0 || index + duration > timeSlots.length) return false
  return timeSlots.slice(index, index + duration).every((slot) => !isOccupied(state, date, courtId, slot))
}

export function bookingTimes(booking: DemoBooking) {
  const index = timeSlots.indexOf(booking.time)
  if (index < 0) return [booking.time]
  return timeSlots.slice(index, index + booking.duration)
}

export function money(value: number) {
  return new Intl.NumberFormat('en-PH', { style: 'currency', currency: 'PHP', maximumFractionDigits: 0 }).format(value)
}

export function shortDate(iso: string) {
  const d = new Date(`${iso}T12:00:00`)
  return d.toLocaleDateString('en-PH', { month: 'short', day: 'numeric', year: 'numeric' })
}

export function makeReference(state: DemoState) {
  const max = state.bookings.reduce((n, b) => Math.max(n, Number(b.id.split('-')[1]) || 2050), 2050)
  return `PRV-${max + 1}`
}
