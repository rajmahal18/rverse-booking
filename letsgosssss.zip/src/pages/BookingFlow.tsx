import { useEffect, useMemo, useState } from 'react'
import { AnimatePresence, motion } from 'motion/react'
import { Link, useSearchParams } from 'react-router-dom'
import DemoBar from '../components/DemoBar'
import PickleRVerseBrand from '../components/PickleRVerseBrand'
import { Arrow, CheckIcon, UploadIcon } from '../components/Icons'
import { courts, isDurationAvailable, isOccupied, loadDemoState, makeDates, makeReference, money, saveDemoState, timeSlots, venue, type DemoBooking } from '../lib/demoStore'

const steps = ['Schedule','Details','Payment','Done']

export default function BookingFlow() {
  const [params] = useSearchParams()
  const dates = makeDates(7)
  const initialCourt = courts.some(c => c.id === params.get('court')) ? params.get('court')! : courts[0].id
  const initialDate = dates.some(d => d.iso === params.get('date')) ? params.get('date')! : dates[0].iso
  const initialTime = params.get('time') && timeSlots.includes(params.get('time')!) ? params.get('time')! : timeSlots[0]
  const [step, setStep] = useState(0)
  const [courtId, setCourtId] = useState(initialCourt)
  const [date, setDate] = useState(initialDate)
  const [time, setTime] = useState(initialTime)
  const [duration, setDuration] = useState(1)
  const [name, setName] = useState('Alex Dela Cruz')
  const [phone, setPhone] = useState('0917 123 4567')
  const [email, setEmail] = useState('alex@example.com')
  const [payment, setPayment] = useState<'online'|'manual'>('online')
  const [onlineMethod, setOnlineMethod] = useState('GCash')
  const [proofName, setProofName] = useState('sample-payment-proof.jpg')
  const [reference, setReference] = useState('')
  const [state, setState] = useState(loadDemoState())

  const court = courts.find(c => c.id === courtId)!
  const convenience = duration * 10
  const subtotal = court.rate * duration
  const total = subtotal + convenience
  const selectedIndex = timeSlots.indexOf(time)
  const selectedRange = selectedIndex >= 0 ? timeSlots.slice(selectedIndex, selectedIndex + duration) : []

  useEffect(() => {
    if (!isDurationAvailable(state,date,courtId,time,duration)) {
      const first = timeSlots.find(t => isDurationAvailable(state,date,courtId,t,duration))
      if (first) setTime(first)
    }
  }, [courtId,date,duration,state,time])

  const schedule = useMemo(() => timeSlots.map(slotTime => {
    const occupied = isOccupied(state,date,courtId,slotTime)
    const canStart = isDurationAvailable(state,date,courtId,slotTime,duration)
    const selected = selectedRange.includes(slotTime)
    return { time: slotTime, occupied, canStart, selected, isStart: slotTime === time }
  }), [state,date,courtId,duration,time])

  function completeBooking() {
    const fresh = loadDemoState()
    const id = makeReference(fresh)
    const booking: DemoBooking = {
      id,
      customer:name || 'Demo Guest',
      phone,
      courtId,
      courtName:court.name,
      date,
      time,
      duration,
      amount:total,
      paymentMethod: payment === 'online' ? onlineMethod : 'Manual proof',
      paymentStatus: payment === 'online' ? 'Paid' : 'Pending review',
      source:'Public',
      proofName: payment === 'manual' ? proofName : undefined,
      createdAt:new Date().toISOString(),
    }
    const next = { ...fresh, bookings:[booking,...fresh.bookings] }
    saveDemoState(next)
    setState(next)
    setReference(id)
    setStep(3)
    window.scrollTo({top:0,behavior:'smooth'})
  }

  function next() { setStep(s => Math.min(2,s+1)); window.scrollTo({top:0,behavior:'smooth'}) }
  function back() { setStep(s => Math.max(0,s-1)); window.scrollTo({top:0,behavior:'smooth'}) }

  return (
    <div className="booking-shell">
      <DemoBar />
      <header className="booking-nav">
        <Link to="/demo" className="court-brand court-brand-image booking-brand"><PickleRVerseBrand /></Link>
        <Link to="/demo">Close booking ×</Link>
      </header>

      <main className="booking-main">
        <div className="booking-progress">{steps.map((s,i) => <div className={i===step?'active':i<step?'done':''} key={s}><span>{i<step?<CheckIcon/>:i+1}</span><small>{s}</small></div>)}</div>

        <AnimatePresence mode="wait" initial={false}>
          {step===0 && (
            <motion.section className="booking-step" key="schedule" initial={{opacity:0,y:10}} animate={{opacity:1,y:0}} exit={{opacity:0,y:-8}} transition={{duration:.2}}>
              <div className="step-head"><span>01 / Schedule</span><h1>Choose your court and time.</h1><p>Orbit, Nova, and Comet share one live schedule from 7 AM to 10 PM.</p></div>
              <div className="booking-layout">
                <div className="booking-fields">
                  <label>Choose a court</label>
                  <div className="court-choice-list custom-court-choice-list">{courts.map(c => <motion.button layout className={courtId===c.id?'selected':''} key={c.id} onClick={()=>setCourtId(c.id)} whileTap={{scale:.985}}><b>{c.number}</b><span><strong>{c.name}</strong><small>{c.surface} · {c.note}</small></span><span>{money(c.rate)}/hr</span></motion.button>)}</div>

                  <label>Choose a date</label>
                  <div className="booking-dates booking-dates-simple">{dates.map((d,i) => <motion.button layout key={d.iso} className={date===d.iso?'selected':''} onClick={()=>setDate(d.iso)} whileTap={{scale:.97}}><strong>{d.label}</strong><small>{i < 2 ? `${d.dow}, ${d.month} ${Number(d.day)}` : `${d.month} ${Number(d.day)}`}</small></motion.button>)}</div>

                  <div className="duration-before-time">
                    <div><label>How long?</label><small>Availability below updates with the duration.</small></div>
                    <div className="duration-switch">{[1,2,3].map(hours => <button className={duration===hours?'selected':''} key={hours} onClick={()=>setDuration(hours)}>{hours} hr{hours>1?'s':''}</button>)}</div>
                  </div>

                  <div className="time-list-head"><div><label>Choose a start time</label><small>{duration > 1 ? `A start time needs ${duration} consecutive open hours.` : 'Booked hours cannot be selected.'}</small></div><span>7 AM → 9 PM</span></div>
                  <div className="booking-time-list">
                    {schedule.map((slot,index) => {
                      const openButTooShort = !slot.occupied && !slot.canStart && !slot.selected
                      const disabled = slot.occupied || (!slot.canStart && !slot.selected)
                      const status = slot.selected
                        ? slot.isStart ? 'Starts here' : 'Your booking'
                        : slot.occupied ? 'Booked'
                        : openButTooShort ? `Not available for ${duration}h`
                        : 'Available'
                      return (
                        <motion.button
                          layout
                          key={slot.time}
                          disabled={disabled}
                          className={`time-row${slot.selected?' selected':''}${slot.isStart&&slot.selected?' start':''}${slot.occupied?' occupied':''}${openButTooShort?' short-window':''}`}
                          onClick={()=>slot.canStart&&setTime(slot.time)}
                          whileTap={disabled ? undefined : {scale:.995}}
                        >
                          <span className="time-index">{String(index+1).padStart(2,'0')}</span>
                          <strong>{slot.time}</strong>
                          <span className="time-line"><i></i></span>
                          <small>{status}</small>
                          {slot.isStart && slot.selected && <motion.b layoutId="selected-time-marker">{duration}h</motion.b>}
                        </motion.button>
                      )
                    })}
                  </div>
                </div>

                <aside className="booking-summary branded-booking-summary">
                  <div className="booking-summary-brand"><PickleRVerseBrand markOnly/><span>{venue.locationLabel}</span></div>
                  <span>Your booking</span>
                  <h3>{court.name}</h3>
                  <dl>
                    <div><dt>Date</dt><dd>{dates.find(d=>d.iso===date)?.label}</dd></div>
                    <div><dt>Time</dt><dd>{time} · {duration}h</dd></div>
                    <div><dt>Court rental</dt><dd>{money(subtotal)}</dd></div>
                    <div><dt>Convenience fee</dt><dd>{money(convenience)}</dd></div>
                  </dl>
                  <div className="summary-total"><span>Total</span><strong>{money(total)}</strong></div>
                  <button className="book-next" onClick={next}>Continue <Arrow/></button>
                </aside>
              </div>
            </motion.section>
          )}

          {step===1 && (
            <motion.section className="booking-step narrow-step" key="details" initial={{opacity:0,y:10}} animate={{opacity:1,y:0}} exit={{opacity:0,y:-8}} transition={{duration:.2}}>
              <div className="step-head"><span>02 / Details</span><h1>Who is the booking for?</h1><p>This is a demo. The pre-filled details are dummy data and can be changed.</p></div>
              <div className="details-card">
                <label>Name<input value={name} onChange={e=>setName(e.target.value)} /></label>
                <label>Mobile number<input value={phone} onChange={e=>setPhone(e.target.value)} /></label>
                <label>Email <small>optional</small><input value={email} onChange={e=>setEmail(e.target.value)} /></label>
                <div className="detail-policy"><CheckIcon/><p>PickleRVerse allows rescheduling at least 6 hours before play.</p></div>
                <div className="step-actions"><button onClick={back}>Back</button><button className="book-next" onClick={next}>Continue to payment <Arrow/></button></div>
              </div>
            </motion.section>
          )}

          {step===2 && (
            <motion.section className="booking-step" key="payment" initial={{opacity:0,y:10}} animate={{opacity:1,y:0}} exit={{opacity:0,y:-8}} transition={{duration:.2}}>
              <div className="step-head"><span>03 / Payment</span><h1>Choose a payment path.</h1><p>No real charge happens in this demo.</p></div>
              <div className="payment-layout">
                <div className="payment-methods">
                  <button className={payment==='online'?'selected':''} onClick={()=>setPayment('online')}><span><strong>Pay online</strong><small>Simulated instant payment</small></span><span>Instant</span></button>
                  <button className={payment==='manual'?'selected':''} onClick={()=>setPayment('manual')}><span><strong>Upload payment proof</strong><small>Staff verifies the proof from Admin</small></span><span>Manual</span></button>

                  <AnimatePresence mode="wait" initial={false}>
                    {payment==='online' ? (
                      <motion.div className="online-panel" key="online" initial={{opacity:0,y:8}} animate={{opacity:1,y:0}} exit={{opacity:0,y:-6}}>
                        <label>Demo payment method</label>
                        <div>{['GCash','Maya','Card'].map(m=><button className={onlineMethod===m?'selected':''} key={m} onClick={()=>setOnlineMethod(m)}>{m}</button>)}</div>
                        <div className="fake-checkout branded-checkout"><div className="checkout-brand"><PickleRVerseBrand markOnly/><span>{venue.paymentName}</span></div><span>{onlineMethod} checkout</span><strong>{money(total)}</strong><p>Completing this step creates a Paid booking in the shared demo state.</p><button onClick={completeBooking}>Complete demo payment <Arrow/></button></div>
                      </motion.div>
                    ) : (
                      <motion.div className="manual-panel" key="manual" initial={{opacity:0,y:8}} animate={{opacity:1,y:0}} exit={{opacity:0,y:-6}}>
                        <div className="sample-proof-card">
                          <div className="proof-brand"><PickleRVerseBrand markOnly/><span>{venue.paymentName}</span></div>
                          <span>Sample payment proof</span>
                          <strong>Mobile Wallet Receipt</strong>
                          <dl><div><dt>Amount sent</dt><dd>{money(total)}</dd></div><div><dt>Reference</dt><dd>8462 1109 5721</dd></div><div><dt>Recipient</dt><dd>{venue.paymentName}</dd></div><div><dt>Mobile</dt><dd>{venue.paymentNumber}</dd></div></dl>
                          <small>Demo receipt · not a real transaction</small>
                        </div>
                        <label className="proof-upload"><UploadIcon/><span><strong>Attach payment proof</strong><small>{proofName}</small></span><input type="file" accept="image/*" onChange={e=>setProofName(e.target.files?.[0]?.name || proofName)}/><b>Choose file</b></label>
                        <p>The booking will appear in Court Staff view as <strong>Pending review</strong>. Staff can open the record and mark it Paid.</p>
                        <button className="manual-submit" onClick={completeBooking}>Submit booking for review <Arrow/></button>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
                <aside className="booking-summary compact branded-booking-summary"><div className="booking-summary-brand"><PickleRVerseBrand markOnly/><span>{venue.locationLabel}</span></div><span>Payment summary</span><h3>{court.name}</h3><dl><div><dt>{duration} hour{duration>1?'s':''} × {money(court.rate)}</dt><dd>{money(subtotal)}</dd></div><div><dt>Convenience fee</dt><dd>{money(convenience)}</dd></div></dl><div className="summary-total"><span>Total</span><strong>{money(total)}</strong></div><button className="summary-back" onClick={back}>← Edit booking</button></aside>
              </div>
            </motion.section>
          )}

          {step===3 && (
            <motion.section className="booking-complete" key="done" initial={{opacity:0,scale:.99}} animate={{opacity:1,scale:1}} transition={{type:'spring',stiffness:240,damping:24}}>
              <div className="complete-brand"><PickleRVerseBrand /></div><motion.div className="complete-check" initial={{scale:.6,rotate:-10}} animate={{scale:1,rotate:0}} transition={{type:'spring',stiffness:360,damping:18}}><CheckIcon/></motion.div>
              <span>{payment==='online'?'Booking confirmed':'Booking received'}</span>
              <h1>{reference}</h1>
              <p>{payment==='online'?'The demo booking is marked Paid.':'The payment proof is waiting for staff review.'}</p>
              <div className="confirmation-card"><div><span>Court</span><strong>{court.name}</strong></div><div><span>Date</span><strong>{dates.find(d=>d.iso===date)?.label}</strong></div><div><span>Time</span><strong>{time} · {duration}h</strong></div><div><span>Total</span><strong>{money(total)}</strong></div><div><span>Payment</span><strong className={payment==='online'?'paid-text':'pending-text'}>{payment==='online'?'Paid':'Pending review'}</strong></div></div>
              <div className="confirmation-venue"><span>{venue.address}</span><span>{venue.hours}</span><span>{venue.phone}</span></div>
              <div className="complete-actions"><Link className="book-next" to="/demo/admin">Open Court Staff view <Arrow/></Link><Link to="/demo">Back to PickleRVerse</Link></div>
            </motion.section>
          )}
        </AnimatePresence>
      </main>
    </div>
  )
}
